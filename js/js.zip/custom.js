(function ($) {
  "use strict";

  $(document).ready(function () {
    $(".sidebar-toggler2").on("click", function () {
      if (!$("body").hasClass("sidebar-md") && !$("body").hasClass("sidebar-sm")) {
        $("body").toggleClass("sidebar-hidden");
      }
    });

    $(".lu-calendar").flatpickr({
      // enableTime: true,
      dateFormat: "d-m-Y"
    });

    $(".lu-calendar-time").flatpickr({
      enableTime: true,
      dateFormat: "d-m-Y H:i"
    });

    $('input.form-control').blur(function () {
      $(this).val() ? $(this).addClass('campo-lleno') : $(this).removeClass('campo-lleno')
    });
  });
})(jQuery);