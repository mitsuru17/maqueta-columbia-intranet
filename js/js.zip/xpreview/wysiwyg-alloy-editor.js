(function ($) {
  'use strict';

  $(document).ready(function() {
    /*var options = {
      modules: {
        toolbar: '#toolbar'
      },
      placeholder: 'Compose an epic...',
      theme: 'snow'
    };
    var editor = new Quill('#editor', options);*/

    AlloyEditor.editable('m-alloy-editor');
  });
})(jQuery);
