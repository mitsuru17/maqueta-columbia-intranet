(function ($) {
  'use strict';

  $(document).ready(function() {
    var formWizard = new FormWizard('#form-wizard-a');
  });
})(jQuery);
