(function ($) {
    'use strict';
  
    $(document).ready(function() {
      var reportCountList1 = [48,45,52,38,65,50,75];
      var reportCountList2 = [30,25,45,55,30,33,50];
  
      var lineCompositeData = {
        labels: ["Lun", "Mar", "Mie", "Jue", "Vie", "Sab", "Dom"],
        datasets: [{
          "name": "Event 1",
          "values": reportCountList1
        },
        {
          "name": "Event 2",
          "values": reportCountList2
        }]
      };
  
      var lineCompositeChart1 = new Chart ('.chart-ex1', {
        title: "Reporte Semanal",
        data: lineCompositeData,
        type: 'line',
        height: 250,
        colors: ['red'],
        isNavigable: 0,
        valuesOverPoints: 0,
  
        lineOptions: {
          dotSize: 7
        }
        // yAxisMode: 'tick'
        // regionFill: 1
      });
  
      var lineCompositeChart2 = new Chart ('.chart-ex2', {
        title: "Reporte Mensual",
        data: lineCompositeData,
        type: 'line',
        height: 250,
        colors: ['red'],
        isNavigable: 0,
        valuesOverPoints: 0,
  
        lineOptions: {
          dotSize: 7
        }
        // yAxisMode: 'tick'
        // regionFill: 1
      });
  
    });
  })(jQuery);